import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score, ShuffleSplit, GridSearchCV
from sklearn import svm
from sklearn import tree
from sklearn.metrics import classification_report, confusion_matrix
import json
from sklearn.feature_extraction.text import *
import seaborn as sns
import matplotlib.pylab as plt

ds = []
filename = './noduplicatedataset.json'
ds = pd.read_json(filename,  lines=True)
print('Loaded: %d samples.' %(len(ds.id)))


X_all = HashingVectorizer().fit_transform(ds.lista_asm)
#X_all = CountVectorizer().fit_transform(ds.lista_asm)
y_all = ds.semantic


X_train, X_test, y_train, y_test = train_test_split(X_all, y_all, 
test_size=0.333, random_state=117)
print("Size of training set: %d" %X_train.shape[0])
print("Size of test set: %d" %X_test.shape[0])


model = tree.DecisionTreeClassifier()
#model = svm.SVC(kernel='linear', C=1)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)


print("Accuracy %.3f" %model.score(X_test, y_test))
cm = confusion_matrix(y_test, y_pred)

x_axis_labels = ['encryption','math','sort','string']
y_axis_labels = ['encryption','math','sort','string']

print(sns.heatmap(cm/np.sum(cm), xticklabels=x_axis_labels, 
yticklabels=y_axis_labels, annot=True, fmt='.3%', cmap='Greens'))

print(classification_report(y_test, y_pred))


ds_blind = []
filename1 = './blindtest.json'
ds_blind = pd.read_json(filename1,  lines=True)
print('Loaded: %d samples.' %(len(ds_blind.id)))

out_file = open("1750157.txt","w")

for i in range(0,len(ds_blind)):
  instance = np.array([ds_blind.lista_asm[i]])
  instance_x = HashingVectorizer().fit_transform(instance)
  instance_y = model.predict(instance_x)
  out_file.write(str(instance_y)[2:-2] + "\n")

out_file.close()

print("Overall score: %.3f" %(model.score(X_all,y_all)))
plt.show()

