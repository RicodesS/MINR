# Prerequirements

If you are working on the computers within the pool rooms everything should be installed.

If you are working with your own computer you have to install CMake (https://cmake.org/).

All other necessary libraries will be loaded, compiled and linked automatically.

## Windows

Go to the download page and choose the correct download for your system.

## Linux

Either the Software Center if you are using Ubuntu, or just:
apt-get install cmake (If you want to use a gui also install [cmake-qt-gui])

## MacOSX

First of all I'm not familiar with MacOSX, so it could be that there are some errors.
If you are using MacOSX 10.8 there seems to be a problem with the installer of the CMake homepage, instead try this:
ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
brew install cmake


# Usage

There are two ways of working with cmake. Using the gui application (cmake-gui) or using the command line tool cmake. In both ways it's appropriate to create a separate build directory (e.g. 'myBuild'). 

For the command line version open a console within the directory 'opengl-series' and after that:
mkdir myBuild; cd myBuild
cmake ../

That's it. Ater that you should be able to build all tutorials by using make in the console, e.g. 'make 01_project_skeleton'.
