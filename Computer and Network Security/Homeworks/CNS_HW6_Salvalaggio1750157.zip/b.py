import socket
import sys
import random
from Crypto import Random
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.PublicKey import RSA
from base64 import b64decode
from Crypto.Util.Padding import unpad
import json
import os
from Crypto.Random import get_random_bytes
import time

print("B")
key = RSA.generate(2048)

private_key = key.export_key()

file_out = open("privateb.pem", "wb")
file_out.write(private_key)
file_out.close()

public_key = key.publickey().export_key()

file_out = open("receiverb.pem", "wb")
file_out.write(public_key)
file_out.close()


time.sleep(3)
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server_address = ('localhost', 9000)
print("B: ")
print (sys.stderr, 'connecting to %s port %s' % server_address)
sock.connect(server_address)

data = "Hi, I am B.".encode("utf-8")

recipient_key = RSA.import_key(open("receiverb.pem").read())
session_key = get_random_bytes(16)

cipher_rsa = PKCS1_OAEP.new(recipient_key)
enc_session_key = cipher_rsa.encrypt(session_key)

cipher_aes = AES.new(session_key, AES.MODE_EAX)
ciphertext, tag = cipher_aes.encrypt_and_digest(data)


sock.send(enc_session_key)

sock.send(tag)

sock.send(cipher_aes.nonce)

sock.send(ciphertext)
print("sending key to C...")
filename='privateb.pem'
length = os.path.getsize(filename)
length = length.to_bytes(4, byteorder='big')

sock.send(length)
f = open(filename,'rb')
l = f.read(1024)
while (l):
    sock.send(l)
    l = f.read(1024)
    if l == "":
        f.close()
f.close()

tag_a = sock.recv(16)

new_pri = sock.recv(16)

size = sock.recv(4) 

size = int.from_bytes(size, byteorder='big')
current_size = 0
print("receiving A private key by C...")
with open('privateacb.pem', 'wb') as f:
    print("file opened")
    while current_size<size:
        print('receiving data...')
        data = sock.recv(1024)
        
        if len(data) + current_size > size:
            data = data[:size-current_size] 
    
        f.write(data)
        current_size += len(data)

f.close()
print("Received!")

private_key = RSA.import_key(open("privateacb.pem").read())


sock.close()




connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server_address = ('localhost', 8000)
print("B: ")
print(sys.stderr, 'starting up on %s port %s' % server_address)
connection.bind(server_address)

connection.listen(1)
print("B: ")
print(sys.stderr, 'waiting for a connection')
connection, client_address = connection.accept()

try:
	print("B: ")
	print(sys.stderr, 'connection from', client_address)
	connection.send(tag)
	tag_client = connection.recv(16)
	if tag_client == tag_a:
		print("receiving messages:")
		nonce = connection.recv(16)
		tag = connection.recv(16)
		ciphertext = connection.recv(2048)
		cipher = AES.new(new_pri, AES.MODE_EAX, nonce)
		plaintext= cipher.decrypt_and_verify(ciphertext, tag)
		print(plaintext.decode('utf-8'))
		nonce = connection.recv(16)
		tag = connection.recv(16)
		ciphertext = connection.recv(2048)
		cipher = AES.new(new_pri, AES.MODE_EAX, nonce)
		plaintext= cipher.decrypt_and_verify(ciphertext, tag)
		print(plaintext.decode('utf-8'))
finally:
	connection.close()