import socket
import sys
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.PublicKey import RSA
from Crypto import Random
import random
from Crypto.Util.Padding import pad
from base64 import b64encode
import json
import os
from Crypto.Random import get_random_bytes
import time

print("A: " + "A")
key = RSA.generate(2048)

private_key = key.export_key()

file_out = open("privatea.pem", "wb")
file_out.write(private_key)
file_out.close()

public_key = key.publickey().export_key()

file_out = open("receivera.pem", "wb")
file_out.write(public_key)
file_out.close()
key = private_key[:16]
data = "Hi, I am A.".encode('utf-8')
print("A: ")


sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server_address = ('localhost', 9000)
print (sys.stderr, 'connecting to %s port %s' % server_address)
sock.connect(server_address)


pri = private_key

recipient_key = RSA.import_key(open("receivera.pem").read())
session_key = get_random_bytes(16)

cipher_rsa = PKCS1_OAEP.new(recipient_key)
enc_session_key = cipher_rsa.encrypt(session_key)

cipher_aes = AES.new(session_key, AES.MODE_EAX)
ciphertext, tag = cipher_aes.encrypt_and_digest(data)


sock.send(enc_session_key)
sock.send(tag)
sock.send(cipher_aes.nonce)
sock.send(ciphertext)

new_pri = get_random_bytes(16)
print("A: " + "sending key to C...")
sock.send(new_pri)

filename='privatea.pem'
length = os.path.getsize(filename)
length = length.to_bytes(4, byteorder='big')

sock.send(length)
f = open(filename,'rb')
l = f.read(1024)
while (l):
    sock.send(l)
    l = f.read(1024)
    if l == "":
        f.close()
f.close()

print("A: " + "Sent!")



tag_b = sock.recv(16)
sock.close()


time.sleep(5)
data = "Hola".encode("utf-8")

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server_address = ('localhost', 8000)
print("A: ")
print (sys.stderr, 'connecting to %s port %s' % server_address)
sock.connect(server_address)
print("A: " + "Sending messages:")
tag_server = sock.recv(16)
if tag_server == tag_b:
    sock.send(tag)
    print("A: " + data.decode('utf-8'))
    cipher = AES.new(new_pri, AES.MODE_EAX)
    nonce = cipher.nonce
    ciphertext, tag = cipher.encrypt_and_digest(data)
    sock.send(nonce)
    sock.send(tag)
    sock.send(ciphertext)

    data = "Here we go".encode("utf-8")
    print("A: " + data.decode('utf-8'))
    cipher = AES.new(new_pri, AES.MODE_EAX)
    nonce = cipher.nonce
    ciphertext, tag = cipher.encrypt_and_digest(data)
    sock.send(nonce)
    sock.send(tag)
    sock.send(ciphertext)
    print("A: " + "Sent!")

sock.close()


