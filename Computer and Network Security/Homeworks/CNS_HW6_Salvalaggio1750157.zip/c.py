import socket
import sys
import random
from Crypto import Random
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.PublicKey import RSA
from base64 import b64decode
from Crypto.Util.Padding import unpad
import json
import os
print("C: " + "C")
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server_address = ('localhost', 9000)
print("C: ")
print(sys.stderr, 'starting up on %s port %s' % server_address)
sock.bind(server_address)

sock.listen(1)
s = b''

print("C: " )
print(sys.stderr, 'waiting for a connection')
connection, client_address = sock.accept()

try:
    print("C: ")
    print(sys.stderr, 'connection from', client_address)
    
    public_a = connection.recv(256)
    tag_a = connection.recv(16)
    nonce_a = connection.recv(16)
    cipher_a = connection.recv(11)
    new_pri = connection.recv(16)

    size = connection.recv(4)

    size = int.from_bytes(size, byteorder='big')
    current_size = 0

    with open('privateac.pem', 'wb') as f:
        print("C: " + "file opened")
        while current_size<size:
            print("C: " + 'receiving data...')
            data = connection.recv(1024)
            
            if len(data) + current_size > size:
                data = data[:size-current_size] 
        
            f.write(data)
            current_size += len(data)


    f.close()


    print("C: " + "Received key!")
    private_keya = RSA.import_key(open("privateac.pem").read())

    cipher_rsa = PKCS1_OAEP.new(private_keya)
    session_keya = cipher_rsa.decrypt(public_a)

    cipher_aes = AES.new(session_keya, AES.MODE_EAX, nonce_a)
    data = cipher_aes.decrypt_and_verify(cipher_a, tag_a)
    print("C: ")
    print(sys.stderr, 'waiting for a connection')
    connectionb, client_addressa = sock.accept()

    print("C: ")
    print(sys.stderr, 'connection from', client_addressa)
    
    public_b = connectionb.recv(256)
    tag_b = connectionb.recv(16)
    nonce_b = connectionb.recv(16)
    cipher_b = connectionb.recv(2048)
    
    size = connectionb.recv(4) 

    size = int.from_bytes(size, byteorder='big')
    current_size = 0

    with open('privatebc.pem', 'wb') as f:
        print("C: " + "file opened")
        while current_size<size:
            print("C: " + 'receiving data...')
            data = connectionb.recv(1024)
            
            if len(data) + current_size > size:
                data = data[:size-current_size] 
        
            f.write(data)
            current_size += len(data)


    f.close()


    print("C: " + "Received key!")

    private_keyb = RSA.import_key(open("privatebc.pem").read())

    cipher_rsa = PKCS1_OAEP.new(private_keyb)
    session_key = cipher_rsa.decrypt(public_b)

    cipher_aes = AES.new(session_key, AES.MODE_EAX, nonce_b)
    data = cipher_aes.decrypt_and_verify(cipher_b, tag_b)
    print("C: " + data.decode("utf-8"))


    connection.send(tag_b)    
    
    connectionb.send(tag_a)
    connectionb.send(new_pri)

    filename='privateac.pem' 
    length = os.path.getsize(filename)
    length = length.to_bytes(4, byteorder='big')
    connectionb.send(length)
    f = open(filename,'rb')
    l = f.read(1024)
    while (l):
        connectionb.send(l)
        l = f.read(1024)
        if l == "":
            f.close()
    f.close()

    print("C: " + "Inviato!")


finally:
    connection.close()
    connectionb.close()


