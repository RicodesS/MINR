import os

os.system("gnome-terminal -e 'bash -c \"python3 c.py; exec bash\"'")
os.system("gnome-terminal -e 'bash -c \"python3 a.py; exec bash\"'")
os.system("gnome-terminal -e 'bash -c \"python3 b.py; exec bash\"'")